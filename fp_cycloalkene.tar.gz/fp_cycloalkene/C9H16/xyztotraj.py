from ase import Atoms
from ase.io import read, write

# Read the XYZ file
atoms = read('centered_molecule.xyz')

#Write to.traj file
write('init.traj',atoms)
