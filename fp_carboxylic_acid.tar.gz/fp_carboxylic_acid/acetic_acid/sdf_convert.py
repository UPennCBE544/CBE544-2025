from ase import Atoms
from ase.io import read, write
import numpy as np
import glob
# Read the SDF file
molecule = glob.glob("*.sdf")
molecule = read(molecule[0])
# Write to XYZ format
write('molecule.xyz', molecule)