import numpy as np
import ase
import os
from ase import io, Atom, Atoms
from ase.visualize import view
from ase.data import atomic_numbers, covalent_radii
from math import sqrt

# Read the main structure and the C4H10 trajectory
a = io.read('scf.out')
ads = io.read('pathway/to/adsorbate/scf.out')

# Select the reference atom from the C4H10 molecule
index_ads1 = int(input('Enter the index of the start reference atom: '))
index_ads2 = int(input('Enter the index of the end atom: '))

# Select adsorption site indices from the main structure
index1 = int(input('Enter index of M or C to adsorb ads on: '))
index2 = int(input('Enter index of surface atom in plane with adsorption site: '))
index3 = int(input('Enter index of surface atom in plane with adsorption site: '))
index4 = input('Enter the position of the adsorbate: ')

# Get positions for the plane and compute normal vector
pos = a.get_positions()
surfacevec1 = pos[index2] - pos[index1]
surfacevec2 = pos[index3] - pos[index1]

# Set up new coordinate system
t = np.cross(surfacevec1, surfacevec2)
t = t * np.sign(t[2])
t = t / np.linalg.norm(t)

# Get covalent radii and unit scaling for adsorbate placement
n = a.cell[0][0] / 2

# Compute the adsorption basis point based on the chosen index4 position
if index4 == 'fcc':
    basis = a[index1].position + t * n * sqrt(2)
elif index4 == 'fcc-':
    basis = a[index1].position - t * n * sqrt(2)
elif index4 == 'top':
    basis = a[index1].position + t * n * 0.5
elif index4 == 'top-':
    basis = a[index1].position - t * n * 0.5
elif index4 == 'hcp':
    basis = a[index1].position + t * n
elif index4 == 'hcp-':
    basis = a[index1].position - t * n
else:
    raise ValueError("Invalid adsorbate position. Choose between 'fcc', 'fcc-', 'top', 'top-', 'hcp', 'hcp-'.")

# Get the position of the reference atom in C4H10
reference_position_ads = ads[index_ads1].position

# Calculate the translation vector to align the reference atom with the adsorption site
translation_vector = basis - reference_position_ads

# Translate the entire C4H10 molecule so that it aligns with the adsorption site
ads.translate(translation_vector)

cpos = ads.positions

u = cpos[index_ads2]-cpos[index_ads1]
v = np.cross(t, u)
v = v / np.linalg.norm(v)

if index4 == 'fcc' or index4 == 'top' or index4 == 'hcp':
    ads.rotate(90,v,reference_position_ads)
    if cpos[index_ads1][2] > cpos[index_ads2][2]:
        ads.rotate(180,v,reference_position_ads)
    else:
        ads.rotate(180,v,reference_position_ads)
elif index4 == 'fcc-' or index4 == 'top-' or index4 == 'hcp-':
    ads.rotate(90, v, reference_position_ads)

# Combine the adsorbed C3H8 molecule with the main structure
new_atoms = a + ads

# Center and save the new structure
new_atoms.center(vacuum=11, axis=2)
new_atoms.write('init.traj')
view(new_atoms)
