from ase.io import read, write
import numpy as np

# Read the XYZ file (extended format)
atoms = read('molecule.xyz', format='extxyz')

# Get the atomic positions
positions = atoms.get_positions()

# Calculate the geometric center of the atoms
geometric_center = np.mean(positions, axis=0)

# Get the center of the cell (assuming a cubic or orthorhombic cell)
cell_center = np.diag(atoms.get_cell()) / 2

# Shift the atoms so that the geometric center is at the cell center
shift_vector = cell_center - geometric_center
new_positions = positions + shift_vector

# Update the atomic positions
atoms.set_positions(new_positions)

write('centered_molecule.xyz', atoms)
