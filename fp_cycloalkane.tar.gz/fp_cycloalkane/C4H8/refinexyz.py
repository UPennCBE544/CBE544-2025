file_path = "molecule.xyz"
output_file = "molecule.xyz"
with open(file_path, 'r') as file:
        lines = file.readlines()
lines[1] = "Lattice=\"20.0 0.0 0.0 0.0 20.0 0.0 0.0 0.0 20.0\" Properties=species:S:1:pos:R:3:magmoms:R:1:tags:I:1:forces:R:3 energy=nan pbc=\"F F F\"\n"
i= 2
for x in lines[2:]:
    lines[i] = x[:-2] + "       0.00000000        0       0.00000000       0.00000000       0.00000000\n"
    i= i+1
with open(output_file, 'w') as file:
        file.writelines(lines)
